#!/bin/bash
# Ch Production Pre-Deployment Gate
# Adapted from AVA OLO

set -e

echo "========================================="
echo "CH PRODUCTION PRE-DEPLOYMENT GATE"
echo "========================================="

# Check if service is reachable
SERVICE_URL="${CH_SERVICE_URL:-http://localhost:8080}"
echo "Checking service at: $SERVICE_URL"

# Test endpoints
echo "Testing health endpoint..."
curl -f "$SERVICE_URL/health" || exit 1

echo "Testing version endpoint..."
curl -f "$SERVICE_URL/version" || exit 1

echo "Testing main application..."
curl -f "$SERVICE_URL/" || exit 1

echo "========================================="
echo "✅ ALL CHECKS PASSED - SAFE TO DEPLOY"
echo "========================================="